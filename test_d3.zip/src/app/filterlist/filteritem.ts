export class FilterItem {
    name: string;
    details: {
        name: string;
    }[]
}