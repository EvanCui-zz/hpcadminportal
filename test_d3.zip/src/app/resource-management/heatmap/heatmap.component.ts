import { Component, OnInit, ViewContainerRef} from '@angular/core';
import * as d3 from 'd3';
// import  './input.tsv';
// import  './input1.tsv';
// import  './input2.tsv';
// import  './input3.tsv';
// import  './input4.tsv';
// import  './input5.tsv';
// import  './input6.tsv';
// import  './input7.tsv';
// import  './input8.tsv';
// import  './input9.tsv';

@Component({
  selector: 'heatmap',
  templateUrl: './heatmap.component.html',
  styleUrls: [ './heatmap.component.css' ]
})
export class HeatmapComponent implements OnInit{
    margin = { top: 50, right: 0, bottom: 100, left: 30 };
    width = 1960 - this.margin.left - this.margin.right;
    height = 1960 - this.margin.top - this.margin.bottom;
    gridSize = Math.floor(this.width / 100);
    legendElementWidth = this.gridSize*2;
    buckets = 9;
    colors = ["#ffffd9","#edf8b1","#c7e9b4","#7fcdbb","#41b6c4","#1d91c0","#225ea8","#253494","#081d58"]; // alternatively colorbrewer.YlGnBu[9]
    days = [];
    times = [];
    datasets = ["input.tsv", "input1.tsv","input2.tsv","input3.tsv","input4.tsv","input5.tsv",
        "input6.tsv","input7.tsv","input8.tsv","input9.tsv"];

    elem;


    constructor(private viewContainerRef: ViewContainerRef){}
    ngOnInit(): void {
        for(let i = 0; i <100; i++)
        {
            this.times.push(i+1);
        }

        for(let j = 0; j < 100; j++) {
            this.days.push(j+1);
        }

        this.elem = this.viewContainerRef.element.nativeElement;

        var svg = d3.select(this.elem).select('div').append("svg")
          .attr("width", this.width + this.margin.left + this.margin.right)
          .attr("height", this.height + this.margin.top + this.margin.bottom)
          .append("g")
          .attr("transform", "translate(" + this.margin.left + "," + this.margin.top + ")");

        var dayLabels = svg.selectAll(".dayLabel")
          .data(this.days)
          .enter().append("text")
            .text(function (d) { return d; })
            .attr("x", 0)
            .attr("y", function (d, i) { return i * this.gridSize; })
            .style("text-anchor", "end")
            .attr("transform", "translate(-6," + this.gridSize / 1.5 + ")")
            .attr("class", function (d, i) { return ((i >= 0 && i <= 4) ? "dayLabel mono axis axis-workweek" : "dayLabel mono axis"); });

        var timeLabels = svg.selectAll(".timeLabel")
          .data(this.times)
          .enter().append("text")
            .text(function(d) { return d; })
            .attr("x", function(d, i) { return i * this.gridSize; })
            .attr("y", 0)
            .style("text-anchor", "middle")
            .attr("transform", "translate(" + this.gridSize / 2 + ", -6)")
            .attr("class", function(d, i) { return ((i >= 7 && i <= 16) ? "timeLabel mono axis axis-worktime" : "timeLabel mono axis"); });

      var heatmapChart = function(tsvFile) {
        d3.tsv(tsvFile,
        function(d) {
          return {
            day: +d.day,
            hour: +d.hour,
            value: +d.value
          };
        },
        function(error, data) {
          var colorScale = d3.scale.quantile()
              .domain([0, this.buckets - 1, d3.max(data, function (d) { return d.value; })])
              .range(this.colors);

          var cards = svg.selectAll(".hour")
              .data(data, function(d) {return d.day+':'+d.hour;});

          cards.append("title");

          cards.enter().append("rect")
              .attr("x", function(d) { return (d.hour - 1) * this.gridSize; })
              .attr("y", function(d) { return (d.day - 1) * this.gridSize; })
              .attr("rx", 4)
              .attr("ry", 4)
              .attr("class", "hour bordered")
              .attr("width", this.gridSize)
              .attr("height", this.gridSize)
              .style("fill", this.colors[0])
              .on("click",function(d){
              console.log("start");
              console.log(d.value);
              console.log("end");
            });

          cards.transition().duration(10)
              .style("fill", function(d) { return colorScale(d.value); });

          cards.select("title").text(function(d) { return d.value; });
          
          cards.exit().remove();

          var legend = svg.selectAll(".legend")
              .data([0].concat(colorScale.quantiles()), function(d) { return d; });

          legend.enter().append("g")
              .attr("class", "legend");

          legend.append("rect")
            .attr("x", function(d, i) { return this.legendElementWidth * i; })
            .attr("y", this.height)
            .attr("width", this.legendElementWidth)
            .attr("height", this.gridSize / 2)
            .style("fill", function(d, i) { return this.colors[i]; });

          legend.append("text")
            .attr("class", "mono")
            .text(function(d) { return "≥ " + Math.round(d); })
            .attr("x", function(d, i) { return this.legendElementWidth * i; })
            .attr("y", this.height + this.gridSize);

          legend.exit().remove();

        });  
      };


      setInterval(()=>{
        
        heatmapChart(this.datasets[Math.floor(Math.random()*10)]);
        
      },10000);
    }
    

     
      

 
  
}
